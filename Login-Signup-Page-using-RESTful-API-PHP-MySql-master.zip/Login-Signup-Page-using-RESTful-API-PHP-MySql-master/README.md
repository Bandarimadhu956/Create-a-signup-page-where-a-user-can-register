# PHP MySQL User Signup Login API

Find Step by Step Tutorial here http://codinginfinite.com/create-login-signup-page-using-restful-api-php-mysql-tutorial/
This step by step tutorial will guide you to setup up Login + Signup page using PHP + MySQL API following best practices with folders structure
